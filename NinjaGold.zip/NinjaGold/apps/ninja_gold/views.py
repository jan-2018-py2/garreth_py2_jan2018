# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from datetime import datetime
import random
from django.shortcuts import render, redirect

def index(req):
	if 'gold' not in req.session:
		req.session['gold'] = 0
		req.session['activities'] = []
	context = {
		"gold":req.session['gold'],
		"activities":req.session['activities']
	}
	return render(req, 'ninja_gold/index.html', context)

def process_money(req):
	building = req.POST['building']
	if building == 'farm':
		gold = random.randrange(10,21)
		req.session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	elif building == 'cave':
		gold = random.randrange(5,11)
		req.session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	elif building == 'house':
		gold = random.randrange(2,6)
		req.session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	elif building == 'casino':
		gold = random.randrange(-50,51)
		req.session['activities'].append({'activity': "You entered a {} and earned {} gold pieces.".format(building, gold), 'class':'win'})

	req.session['gold'] += gold
	return redirect('/')


app.run(debug=True)
